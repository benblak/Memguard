import Mathlib.Data.Set.Basic
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Algebra.Order.Monoid.Unbundled.WithTop
import Mathlib.Data.Nat.Find
import Mathlib.Tactic.FinCases

-- ===== Core.lean =====

namespace Insacermo

/-- Minimal contract system: worlds `S`, strategies `Plan`, a contract-satisfaction
    predicate, and a nonnegative integer strategy cost. -/
structure ContractSystem (S Plan : Type*) where
  good : S → Plan → Prop
  cost : Plan → Nat

variable {S Plan Z Y : Type*}

/-- Threshold form of the common-future cost profile:
    `Admissible sys b B` means exactly `β(B) ≤ b`.
    A single strategy must work for every world in `B`. -/
def Admissible (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  ∃ π : Plan, sys.cost π ≤ b ∧ ∀ s ∈ B, sys.good s π

/-- Ambiguity monotonicity / downward closure:
    if one strategy works on `B`, it works on every subset `A ⊆ B`. -/
theorem admissible_mono
    (sys : ContractSystem S Plan) (b : Nat)
    {A B : Set S} (hAB : A ⊆ B) :
    Admissible sys b B → Admissible sys b A := by
  rintro ⟨π, hcost, hgood⟩
  exact ⟨π, hcost, fun s hs => hgood s (hAB hs)⟩

/-- The sublevel family `K_b = {B | β(B) ≤ b}` is downward closed.
    This is the combinatorial core of the simplicial-complex statement. -/
theorem sublevel_downward_closed
    (sys : ContractSystem S Plan) (b : Nat) :
    ∀ {A B : Set S}, A ⊆ B → Admissible sys b B → Admissible sys b A := by
  intro A B hAB hB
  exact admissible_mono sys b hAB hB

/-- A representation is safe when every nonempty fiber has a common strategy
    under budget. Empty codes are irrelevant. -/
def Safe (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) : Prop :=
  ∀ z : Z,
    Set.Nonempty {s : S | h s = z} →
    Admissible sys b {s : S | h s = z}

/-- Operational statement: a controller sees only `h s`, then selects one
    strategy from that code. -/
def Supports (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) : Prop :=
  ∃ d : Z → Plan,
    ∀ s : S,
      sys.cost (d (h s)) ≤ b ∧ sys.good s (d (h s))

/-- Future Compiler Theorem.
    A controller depending only on the representation exists iff every fiber
    of the representation is admissible. -/
theorem futureCompiler_iff
    [Inhabited Plan]
    (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) :
    Supports sys b h ↔ Safe sys b h := by
  classical
  constructor
  · rintro ⟨d, hd⟩ z hz
    rcases hz with ⟨s0, hs0⟩
    refine ⟨d z, ?_, ?_⟩
    · have hc := (hd s0).1
      simpa [hs0] using hc
    · intro s hs
      have hg := (hd s).2
      simpa [hs] using hg
  · intro hsafe
    let d : Z → Plan := fun z =>
      if hz : Set.Nonempty {s : S | h s = z} then
        Classical.choose (hsafe z hz)
      else
        default
    refine ⟨d, ?_⟩
    intro s
    have hz : Set.Nonempty {t : S | h t = h s} := ⟨s, rfl⟩
    have hspec := Classical.choose_spec (hsafe (h s) hz)
    constructor
    · simpa [d, hz] using hspec.1
    · have hg := hspec.2 s rfl
      simpa [d, hz] using hg

/-- Safety of a coarsened representation implies safety of the finer one. -/
theorem safe_of_safe_coarsening
    (sys : ContractSystem S Plan) (b : Nat)
    (h : S → Z) (g : Z → Y) :
    Safe sys b (g ∘ h) → Safe sys b h := by
  intro hcoarse z hz
  rcases hz with ⟨s0, hs0⟩
  have hcoarse_nonempty :
      Set.Nonempty {s : S | (g ∘ h) s = g z} := by
    refine ⟨s0, ?_⟩
    simp [Function.comp_apply, hs0]
  have hAdmCoarse := hcoarse (g z) hcoarse_nonempty
  apply admissible_mono sys b (A := {s : S | h s = z})
      (B := {s : S | (g ∘ h) s = g z})
  · intro s hs
    simp only [Set.mem_setOf_eq] at hs ⊢
    simp [Function.comp_apply, hs]
  · exact hAdmCoarse

/-- Contractual Data-Processing Lemma:
    deterministic post-processing cannot repair an already unsafe representation
    when contract, strategy set and budget are unchanged. -/
theorem unsafe_of_coarsening
    (sys : ContractSystem S Plan) (b : Nat)
    (h : S → Z) (g : Z → Y)
    (hunsafe : ¬ Safe sys b h) :
    ¬ Safe sys b (g ∘ h) := by
  intro hsafe
  exact hunsafe (safe_of_safe_coarsening sys b h g hsafe)

/-- A minimal obstruction is a minimally inadmissible ambiguity set. -/
def MinimalObstruction
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  ¬ Admissible sys b B ∧
    ∀ A : Set S, A ⊂ B → Admissible sys b A

end Insacermo
-- ===== Ternary.lean =====

namespace Insacermo

inductive TState where
  | a | b | c
  deriving DecidableEq

instance : Fintype TState where
  elems := {.a, .b, .c}
  complete := by intro x; cases x <;> simp

inductive TPlan where
  | ab | ac | bc | all
  deriving DecidableEq

instance : Fintype TPlan where
  elems := {.ab, .ac, .bc, .all}
  complete := by intro x; cases x <;> simp

open TState TPlan

def tGood : TState → TPlan → Prop
  | a, ab => True
  | b, ab => True
  | a, ac => True
  | c, ac => True
  | b, bc => True
  | c, bc => True
  | _, all => True
  | _, _ => False


def tCost : TPlan → Nat
  | ab | ac | bc => 1
  | all => 3


def ternarySystem : ContractSystem TState TPlan where
  good := tGood
  cost := tCost


def AB : Set TState := {s | s = a ∨ s = b}
def AC : Set TState := {s | s = a ∨ s = c}
def BC : Set TState := {s | s = b ∨ s = c}

/-- Every pair has a common plan at budget 1. -/
theorem pair_ab_admissible : Admissible ternarySystem 1 AB := by
  refine ⟨ab, by decide, ?_⟩
  intro s hs
  change s = a ∨ s = b at hs
  rcases hs with (rfl | rfl) <;> trivial

theorem pair_ac_admissible : Admissible ternarySystem 1 AC := by
  refine ⟨ac, by decide, ?_⟩
  intro s hs
  change s = a ∨ s = c at hs
  rcases hs with (rfl | rfl) <;> trivial

theorem pair_bc_admissible : Admissible ternarySystem 1 BC := by
  refine ⟨bc, by decide, ?_⟩
  intro s hs
  change s = b ∨ s = c at hs
  rcases hs with (rfl | rfl) <;> trivial

/-- But no single budget-1 plan works for all three worlds.
    This is the canonical pure ternary obstruction: pairwise compatibility
    does not imply global common-future compatibility. -/
theorem triple_not_admissible :
    ¬ Admissible ternarySystem 1 (Set.univ : Set TState) := by
  rintro ⟨π, hcost, hgood⟩
  cases π with
  | ab =>
      have h := hgood c (by simp)
      exact h
  | ac =>
      have h := hgood b (by simp)
      exact h
  | bc =>
      have h := hgood a (by simp)
      exact h
  | all =>
      have hbad : ¬ (3 : Nat) ≤ 1 := by decide
      apply hbad
      simpa [ternarySystem, tCost] using hcost

/-- At budget 3 the universal plan repairs the obstruction. -/
theorem triple_repaired_at_three :
    Admissible ternarySystem 3 (Set.univ : Set TState) := by
  refine ⟨all, by decide, ?_⟩
  intro s hs
  cases s <;> trivial

end Insacermo
-- ===== Beta.lean =====

namespace Insacermo

variable {S Plan Z Y : Type*}

/-- Cost assigned to one strategy for an ambiguity set `B`.
    A strategy that is not contract-valid on all of `B` receives cost `⊤`. -/
noncomputable def candidateCost
    (sys : ContractSystem S Plan) (B : Set S) (π : Plan) : WithTop Nat := by
  classical
  exact if (∀ s ∈ B, sys.good s π) then (sys.cost π : WithTop Nat) else ⊤

/-- Explicit finite common-future cost profile.

`beta sys B` is the minimum cost of one strategy that is contract-valid on every
world in `B`; if no such strategy exists, its value is `⊤`.

This is the finite version of
  β(B) = inf { c(π) | ∀ s ∈ B, good(s,π) }.
-/
noncomputable def beta
    [Fintype Plan]
    (sys : ContractSystem S Plan) (B : Set S) : WithTop Nat := by
  classical
  exact (Finset.univ : Finset Plan).inf (candidateCost sys B)

/-- The explicit `beta` exactly recovers the threshold notion `Admissible`.
    This theorem is the bridge between CORE V0.1 and the explicit cost profile. -/
theorem beta_le_iff_admissible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (B : Set S) (b : Nat) :
    beta sys B ≤ (b : WithTop Nat) ↔ Admissible sys b B := by
  classical
  have hbtop : (b : WithTop Nat) < ⊤ := by simp
  constructor
  · intro hbeta
    have hex :
        ∃ π : Plan, π ∈ (Finset.univ : Finset Plan) ∧
          candidateCost sys B π ≤ (b : WithTop Nat) := by
      exact (Finset.inf_le_iff hbtop).1 (by simpa [beta] using hbeta)
    rcases hex with ⟨π, -, hcost⟩
    by_cases hgood : ∀ s ∈ B, sys.good s π
    · refine ⟨π, ?_, hgood⟩
      simpa [candidateCost, hgood] using hcost
    · simp [candidateCost, hgood] at hcost
  · rintro ⟨π, hcost, hgood⟩
    apply (Finset.inf_le_iff hbtop).2
    refine ⟨π, Finset.mem_univ π, ?_⟩
    simpa [candidateCost, hgood] using hcost

/-- Ambiguity monotonicity in explicit `beta` form:
    enlarging the set of worlds that must share one strategy cannot reduce
    the minimum common-future cost. -/
theorem beta_mono_ambiguity
    [Fintype Plan]
    (sys : ContractSystem S Plan)
    {A B : Set S} (hAB : A ⊆ B) :
    beta sys A ≤ beta sys B := by
  classical
  unfold beta
  apply Finset.inf_mono_fun
  intro π hπ
  by_cases hB : ∀ s ∈ B, sys.good s π
  · have hA : ∀ s ∈ A, sys.good s π := by
      intro s hs
      exact hB s (hAB hs)
    simp [candidateCost, hA, hB]
  · simp [candidateCost, hB]

/-- Explicit sublevel family generated by `beta`. -/
def InSublevel
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  beta sys B ≤ (b : WithTop Nat)

/-- Sublevel membership is exactly threshold admissibility. -/
theorem inSublevel_iff_admissible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    InSublevel sys b B ↔ Admissible sys b B := by
  simpa [InSublevel] using beta_le_iff_admissible sys B b

/-- The `beta` sublevel family is downward closed, hence is the face family
    of a simplicial complex in the finite-world formulation. -/
theorem beta_sublevel_downward_closed
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {A B : Set S} (hAB : A ⊆ B) :
    InSublevel sys b B → InSublevel sys b A := by
  intro hB
  exact le_trans (beta_mono_ambiguity sys hAB) hB

/-- A representation is beta-safe when every nonempty fiber lies below the
    budget sublevel. -/
def BetaSafe
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) : Prop :=
  ∀ z : Z,
    Set.Nonempty {s : S | h s = z} →
    beta sys {s : S | h s = z} ≤ (b : WithTop Nat)

/-- `BetaSafe` is definitionally equivalent, through `beta`, to the V0.1
    threshold notion `Safe`. -/
theorem betaSafe_iff_safe
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) :
    BetaSafe sys b h ↔ Safe sys b h := by
  constructor
  · intro hbeta z hz
    exact (beta_le_iff_admissible sys {s : S | h s = z} b).1 (hbeta z hz)
  · intro hsafe z hz
    exact (beta_le_iff_admissible sys {s : S | h s = z} b).2 (hsafe z hz)

/-- Future Compiler Theorem in explicit common-future-cost form. -/
theorem futureCompiler_beta_iff
    [Fintype Plan] [Inhabited Plan]
    (sys : ContractSystem S Plan) (b : Nat) (h : S → Z) :
    Supports sys b h ↔ BetaSafe sys b h := by
  rw [betaSafe_iff_safe]
  exact futureCompiler_iff sys b h

/-- Beta form of deterministic data processing:
    a coarsening that only post-processes the existing representation cannot
    make an already beta-unsafe representation safe while the contract,
    strategy set and budget are unchanged. -/
theorem betaUnsafe_of_coarsening
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (h : S → Z) (g : Z → Y)
    (hunsafe : ¬ BetaSafe sys b h) :
    ¬ BetaSafe sys b (g ∘ h) := by
  intro hcoarse
  have hcoarseSafe : Safe sys b (g ∘ h) :=
    (betaSafe_iff_safe sys b (g ∘ h)).1 hcoarse
  have hfineSafe : Safe sys b h :=
    safe_of_safe_coarsening sys b h g hcoarseSafe
  exact hunsafe ((betaSafe_iff_safe sys b h).2 hfineSafe)

/-- Budget sublevels are monotone: more budget cannot remove an admissible
    ambiguity set. -/
theorem inSublevel_mono_budget
    [Fintype Plan]
    (sys : ContractSystem S Plan)
    {b₁ b₂ : Nat} (hbb : b₁ ≤ b₂) (B : Set S) :
    InSublevel sys b₁ B → InSublevel sys b₂ B := by
  intro hB
  exact le_trans hB (WithTop.coe_le_coe.2 hbb)

end Insacermo
-- ===== BetaTernary.lean =====

namespace Insacermo

open TState TPlan

/-- Explicit beta certificate for a pair in the ternary counterexample. -/
theorem beta_AB_le_one :
    beta ternarySystem AB ≤ (1 : WithTop Nat) := by
  exact (beta_le_iff_admissible ternarySystem AB 1).2 pair_ab_admissible

/-- The pure ternary obstruction is visible directly in `beta`:
    no common strategy exists at budget 1 for all three worlds. -/
theorem beta_triple_not_le_one :
    ¬ beta ternarySystem (Set.univ : Set TState) ≤ (1 : WithTop Nat) := by
  intro h
  exact triple_not_admissible
    ((beta_le_iff_admissible ternarySystem (Set.univ : Set TState) 1).1 h)

/-- At budget 3 the universal strategy crosses the beta sublevel. -/
theorem beta_triple_le_three :
    beta ternarySystem (Set.univ : Set TState) ≤ (3 : WithTop Nat) := by
  exact (beta_le_iff_admissible ternarySystem (Set.univ : Set TState) 3).2
    triple_repaired_at_three

end Insacermo
-- ===== Obstruction.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- `BoundaryBelow sys b B` means that every strict sub-ambiguity of `B`
    already lies below the common-future budget `b`.  This is the order-theoretic
    content of the inequality `∂β(B) ≤ b`, without requiring a numerical
    maximum to be chosen. -/
def BoundaryBelow
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  ∀ A : Set S, A ⊂ B → beta sys A ≤ (b : WithTop Nat)

/-- Beta characterization of a minimal obstruction.

A set `B` is a minimal obstruction at budget `b` exactly when:
  * every strict sub-ambiguity is already below budget; and
  * `B` itself is still above budget.

This is the threshold form of the obstruction interval
    ∂β(B) ≤ b < β(B).
-/
theorem minimalObstruction_beta_iff
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    MinimalObstruction sys b B ↔
      BoundaryBelow sys b B ∧ ¬ beta sys B ≤ (b : WithTop Nat) := by
  constructor
  · rintro ⟨hB, hproper⟩
    refine ⟨?_, ?_⟩
    · intro A hAB
      exact (beta_le_iff_admissible sys A b).2 (hproper A hAB)
    · intro hbeta
      exact hB ((beta_le_iff_admissible sys B b).1 hbeta)
  · rintro ⟨hboundary, hBbeta⟩
    refine ⟨?_, ?_⟩
    · intro hAdm
      exact hBbeta ((beta_le_iff_admissible sys B b).2 hAdm)
    · intro A hAB
      exact (beta_le_iff_admissible sys A b).1 (hboundary A hAB)

/-- Strict-interval form.  `WithTop Nat` is linearly ordered, so failure of
    `β(B) ≤ b` is equivalent to `b < β(B)`. -/
theorem minimalObstruction_interval_iff
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    MinimalObstruction sys b B ↔
      BoundaryBelow sys b B ∧ (b : WithTop Nat) < beta sys B := by
  rw [minimalObstruction_beta_iff]
  constructor
  · rintro ⟨hboundary, hnot⟩
    exact ⟨hboundary, lt_of_not_ge hnot⟩
  · rintro ⟨hboundary, hlt⟩
    exact ⟨hboundary, not_le_of_gt hlt⟩

/-- Every strict subset of a minimal obstruction is in the beta sublevel. -/
theorem proper_subset_inSublevel_of_minimalObstruction
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {A B : Set S}
    (hB : MinimalObstruction sys b B)
    (hAB : A ⊂ B) :
    InSublevel sys b A := by
  have h := (minimalObstruction_beta_iff sys b B).1 hB
  exact h.1 A hAB

/-- The obstruction itself is outside the beta sublevel. -/
theorem not_inSublevel_of_minimalObstruction
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {B : Set S}
    (hB : MinimalObstruction sys b B) :
    ¬ InSublevel sys b B := by
  have h := (minimalObstruction_beta_iff sys b B).1 hB
  simpa [InSublevel] using h.2

/-- Local simplex-boundary statement in purely combinatorial form:
    on a minimal obstruction `B`, every strict face is present at budget `b`
    while the full simplex `B` is absent. -/
def LocalSimplexBoundary
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  (∀ A : Set S, A ⊂ B → InSublevel sys b A) ∧
  ¬ InSublevel sys b B

/-- Minimal obstructions are exactly local simplex boundaries of the sublevel
    complex.  This is the formal combinatorial core behind the higher-order
    sphere interpretation for finite `B`. -/
theorem minimalObstruction_iff_localSimplexBoundary
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    MinimalObstruction sys b B ↔ LocalSimplexBoundary sys b B := by
  constructor
  · intro hB
    refine ⟨?_, ?_⟩
    · intro A hAB
      exact proper_subset_inSublevel_of_minimalObstruction sys b hB hAB
    · exact not_inSublevel_of_minimalObstruction sys b hB
  · rintro ⟨hproper, hfull⟩
    refine (minimalObstruction_beta_iff sys b B).2 ?_
    constructor
    · intro A hAB
      exact hproper A hAB
    · simpa [InSublevel] using hfull

end Insacermo
-- ===== HigherOrder.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- Generic pairwise blind spot: if a pair is a strict subset of a minimal
    obstruction, that pair is admissible even though the full obstruction is
    not.  Thus pairwise inspection cannot certify away a higher-order minimal
    obstruction. -/
theorem pairwise_blind_spot
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {B : Set S} (hB : MinimalObstruction sys b B)
    {x y : S}
    (hpair : ({x, y} : Set S) ⊂ B) :
    InSublevel sys b ({x, y} : Set S) ∧ ¬ InSublevel sys b B := by
  constructor
  · exact proper_subset_inSublevel_of_minimalObstruction sys b hB hpair
  · exact not_inSublevel_of_minimalObstruction sys b hB

open TState TPlan

/-- Explicit pure ternary pairwise pass: all three canonical pairs lie in the
    budget-1 beta sublevel. -/
theorem ternary_all_pairs_in_sublevel_one :
    InSublevel ternarySystem 1 AB ∧
    InSublevel ternarySystem 1 AC ∧
    InSublevel ternarySystem 1 BC := by
  constructor
  · exact beta_AB_le_one
  · constructor
    · exact (beta_le_iff_admissible ternarySystem AC 1).2 pair_ac_admissible
    · exact (beta_le_iff_admissible ternarySystem BC 1).2 pair_bc_admissible

/-- Explicit pure ternary global failure at the same budget. -/
theorem ternary_triple_outside_sublevel_one :
    ¬ InSublevel ternarySystem 1 (Set.univ : Set TState) := by
  simpa [InSublevel] using beta_triple_not_le_one

/-- Pairwise compatibility is therefore insufficient in the canonical ternary
    system: every pair passes budget 1 while the triple fails. -/
theorem ternary_pairwise_not_global :
    (InSublevel ternarySystem 1 AB ∧
     InSublevel ternarySystem 1 AC ∧
     InSublevel ternarySystem 1 BC) ∧
    ¬ InSublevel ternarySystem 1 (Set.univ : Set TState) := by
  exact ⟨ternary_all_pairs_in_sublevel_one,
    ternary_triple_outside_sublevel_one⟩

/-- The same triple enters the filtration at budget 3 after the universal
    repair strategy becomes affordable. -/
theorem ternary_repair_enters_sublevel_three :
    InSublevel ternarySystem 3 (Set.univ : Set TState) := by
  exact beta_triple_le_three

end Insacermo
-- ===== MemoryCapability.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- Feasibility with at most `k` available representation codes.
Unused codes are allowed, so a map `S → Fin k` represents a memory with
at most `k` realized states. -/
def KStateFeasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b k : Nat) : Prop :=
  ∃ h : S → Fin k, BetaSafe sys b h

/-- Direct budget monotonicity for beta-safe representations. -/
theorem betaSafe_mono_budget
    [Fintype Plan]
    (sys : ContractSystem S Plan)
    {b₁ b₂ : Nat} (hbb : b₁ ≤ b₂)
    {Z : Type*} {h : S → Z} :
    BetaSafe sys b₁ h → BetaSafe sys b₂ h := by
  intro hsafe z hz
  exact le_trans (hsafe z hz) (WithTop.coe_le_coe.2 hbb)

/-- More budget cannot destroy `k`-state feasibility. -/
theorem kStateFeasible_mono_budget
    [Fintype Plan]
    (sys : ContractSystem S Plan)
    {b₁ b₂ k : Nat} (hbb : b₁ ≤ b₂) :
    KStateFeasible sys b₁ k → KStateFeasible sys b₂ k := by
  rintro ⟨h, hsafe⟩
  exact ⟨h, betaSafe_mono_budget sys hbb hsafe⟩

/-- Embedding a safe `k₁`-code representation into a larger code alphabet
preserves beta-safety. -/
theorem betaSafe_fin_castLE
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {k₁ k₂ : Nat} (hkk : k₁ ≤ k₂)
    {h : S → Fin k₁}
    (hsafe : BetaSafe sys b h) :
    BetaSafe sys b (fun s => Fin.castLE hkk (h s)) := by
  intro z₂ hz₂
  rcases hz₂ with ⟨s₀, hs₀⟩
  change Fin.castLE hkk (h s₀) = z₂ at hs₀
  let z₁ : Fin k₁ := h s₀
  have hz₁ : Set.Nonempty {s : S | h s = z₁} := by
    refine ⟨s₀, ?_⟩
    rfl
  have hsub :
      {s : S | Fin.castLE hkk (h s) = z₂} ⊆
      {s : S | h s = z₁} := by
    intro s hs
    change Fin.castLE hkk (h s) = z₂ at hs
    change h s = z₁
    apply Fin.ext
    have hc : Fin.castLE hkk (h s) = Fin.castLE hkk (h s₀) := by
      calc
        Fin.castLE hkk (h s) = z₂ := hs
        _ = Fin.castLE hkk (h s₀) := hs₀.symm
    exact congrArg Fin.val hc
  exact le_trans (beta_mono_ambiguity sys hsub) (hsafe z₁ hz₁)

/-- More available memory codes cannot destroy feasibility. -/
theorem kStateFeasible_mono_states
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {k₁ k₂ : Nat} (hkk : k₁ ≤ k₂) :
    KStateFeasible sys b k₁ → KStateFeasible sys b k₂ := by
  rintro ⟨h, hsafe⟩
  exact ⟨fun s => Fin.castLE hkk (h s), betaSafe_fin_castLE sys b hkk hsafe⟩

/-- Order-theoretic form of `N⋆(b) ≤ k`: there exists a beta-safe
representation using at most `k` codes. -/
def NStarLe
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b k : Nat) : Prop :=
  KStateFeasible sys b k

/-- Order-theoretic form of `b⋆(k) ≤ b`: budget `b` suffices with at most
`k` codes.  It is intentionally defined by the same feasibility relation;
`N⋆` and `b⋆` are the two coordinate views of one frontier. -/
def BStarLe
    [Fintype Plan]
    (sys : ContractSystem S Plan) (k b : Nat) : Prop :=
  KStateFeasible sys b k

/-- Memory-capability frontier theorem, in a form that does not require
choosing minima: `N⋆(b) ≤ k` iff `b⋆(k) ≤ b`.
Both sides are coordinate sections of the same upward-closed feasibility set. -/
theorem memoryCapability_frontier_iff
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b k : Nat) :
    NStarLe sys b k ↔ BStarLe sys k b := by
  rfl

/-- The feasible frontier is upward closed in budget. -/
theorem nStarLe_mono_budget
    [Fintype Plan]
    (sys : ContractSystem S Plan)
    {b₁ b₂ k : Nat} (hbb : b₁ ≤ b₂) :
    NStarLe sys b₁ k → NStarLe sys b₂ k := by
  exact kStateFeasible_mono_budget sys hbb

/-- The feasible frontier is upward closed in the number of codes. -/
theorem nStarLe_mono_states
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    {k₁ k₂ : Nat} (hkk : k₁ ≤ k₂) :
    NStarLe sys b k₁ → NStarLe sys b k₂ := by
  exact kStateFeasible_mono_states sys b hkk

/-- Every feasible representation implies singleton feasibility: perfect
knowledge of one realized world can only be easier than its representation
fiber. -/
theorem singleton_beta_le_of_kStateFeasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b k : Nat)
    (hfeas : KStateFeasible sys b k) :
    ∀ s : S, beta sys ({s} : Set S) ≤ (b : WithTop Nat) := by
  rcases hfeas with ⟨h, hsafe⟩
  intro s
  have hz : Set.Nonempty {t : S | h t = h s} := ⟨s, rfl⟩
  have hsub : ({s} : Set S) ⊆ {t : S | h t = h s} := by
    intro t ht
    simpa using ht
  exact le_trans (beta_mono_ambiguity sys hsub) (hsafe (h s) hz)

/-- Perfect-state coding by the identity representation is beta-safe exactly
when every singleton ambiguity set is under budget.  For finite `S`, the
identity uses exactly `|S|` available codes. -/
theorem betaSafe_id_iff_singletons
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) :
    BetaSafe sys b (fun s : S => s) ↔
      ∀ s : S, beta sys ({s} : Set S) ≤ (b : WithTop Nat) := by
  constructor
  · intro hsafe s
    have hz : Set.Nonempty {t : S | (fun u : S => u) t = s} := ⟨s, rfl⟩
    have h := hsafe s hz
    simpa only [Set.setOf_eq_eq_singleton] using h
  · intro hsingle z hz
    simpa only [Set.setOf_eq_eq_singleton] using hsingle z

/-- With one available memory code, and at least one world, feasibility is
exactly universal common-future feasibility on `S`. -/
theorem oneStateFeasible_iff_univ
    [Fintype Plan] [Nonempty S]
    (sys : ContractSystem S Plan) (b : Nat) :
    KStateFeasible sys b 1 ↔
      beta sys (Set.univ : Set S) ≤ (b : WithTop Nat) := by
  constructor
  · rintro ⟨h, hsafe⟩
    let z : Fin 1 := 0
    obtain ⟨s₀⟩ := (inferInstance : Nonempty S)
    have hz : Set.Nonempty {s : S | h s = z} := by
      refine ⟨s₀, ?_⟩
      exact Subsingleton.elim _ _
    have hb := hsafe z hz
    have hEq : {s : S | h s = z} = Set.univ := by
      ext s
      simp [Subsingleton.elim (h s) z]
    simpa [hEq] using hb
  · intro huniv
    let h : S → Fin 1 := fun _ => 0
    refine ⟨h, ?_⟩
    intro z hz
    have hEq : {s : S | h s = z} = Set.univ := by
      ext s
      simp [h, Subsingleton.elim (0 : Fin 1) z]
    simpa [hEq] using huniv

end Insacermo
-- ===== FrontierMinima.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- Explicit minimum number of available codes at a fixed budget, provided
some finite code budget is feasible. -/
noncomputable def nStar
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (hex : ∃ k : Nat, KStateFeasible sys b k) : Nat := by
  classical
  exact Nat.find hex

/-- Explicit minimum budget at a fixed number of available codes, provided
some finite budget is feasible. -/
noncomputable def bStar
    [Fintype Plan]
    (sys : ContractSystem S Plan) (k : Nat)
    (hex : ∃ b : Nat, KStateFeasible sys b k) : Nat := by
  classical
  exact Nat.find hex

/-- The chosen minimum code count is feasible. -/
theorem nStar_spec
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (hex : ∃ k : Nat, KStateFeasible sys b k) :
    KStateFeasible sys b (nStar sys b hex) := by
  classical
  exact Nat.find_spec hex

/-- The chosen minimum budget is feasible. -/
theorem bStar_spec
    [Fintype Plan]
    (sys : ContractSystem S Plan) (k : Nat)
    (hex : ∃ b : Nat, KStateFeasible sys b k) :
    KStateFeasible sys (bStar sys k hex) k := by
  classical
  exact Nat.find_spec hex

/-- `nStar` is no larger than any feasible code count. -/
theorem nStar_le_of_feasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (hex : ∃ k : Nat, KStateFeasible sys b k)
    {k : Nat} (hk : KStateFeasible sys b k) :
    nStar sys b hex ≤ k := by
  classical
  exact Nat.find_min' hex hk

/-- `bStar` is no larger than any feasible budget. -/
theorem bStar_le_of_feasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (k : Nat)
    (hex : ∃ b : Nat, KStateFeasible sys b k)
    {b : Nat} (hb : KStateFeasible sys b k) :
    bStar sys k hex ≤ b := by
  classical
  exact Nat.find_min' hex hb

/-- Exact threshold characterization of the minimum memory count. -/
theorem nStar_le_iff_feasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (hex : ∃ k : Nat, KStateFeasible sys b k)
    (k : Nat) :
    nStar sys b hex ≤ k ↔ KStateFeasible sys b k := by
  classical
  constructor
  · intro hle
    exact kStateFeasible_mono_states sys b hle (nStar_spec sys b hex)
  · intro hk
    exact nStar_le_of_feasible sys b hex hk

/-- Exact threshold characterization of the minimum budget. -/
theorem bStar_le_iff_feasible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (k : Nat)
    (hex : ∃ b : Nat, KStateFeasible sys b k)
    (b : Nat) :
    bStar sys k hex ≤ b ↔ KStateFeasible sys b k := by
  classical
  constructor
  · intro hle
    exact kStateFeasible_mono_budget sys hle (bStar_spec sys k hex)
  · intro hb
    exact bStar_le_of_feasible sys k hex hb

/-- Explicit memory-capability duality.
Whenever both minima exist, their threshold predicates are equivalent:

  N⋆(b) ≤ k  ↔  b⋆(k) ≤ b.
-/
theorem nStar_le_iff_bStar_le
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b k : Nat)
    (hexN : ∃ j : Nat, KStateFeasible sys b j)
    (hexB : ∃ r : Nat, KStateFeasible sys r k) :
    nStar sys b hexN ≤ k ↔ bStar sys k hexB ≤ b := by
  classical
  rw [nStar_le_iff_feasible sys b hexN k]
  rw [bStar_le_iff_feasible sys k hexB b]

end Insacermo
-- ===== Compiler.lean =====

namespace Insacermo

variable {S Plan Plan' Z Y I : Type*}

/-- User-facing labels of the minimal INSACERMO compiler.  `preserve` is a
    pre-emptive guard; the other labels describe the current response. -/
inductive DecisionLabel where
  | act
  | probe
  | repair
  | preserve
  | refuse
  deriving DecidableEq, Repr

/-- ACT certificate: one explicit strategy satisfies the contract on every
    currently possible world and stays under budget. -/
structure ActCertificate
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) where
  strategy : Plan
  cost_le : sys.cost strategy ≤ b
  good_on : ∀ s ∈ B, sys.good s strategy

/-- Existence of an ACT certificate is exactly threshold admissibility. -/
theorem actCertificate_iff_admissible
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    Nonempty (ActCertificate sys b B) ↔ Admissible sys b B := by
  constructor
  · rintro ⟨cert⟩
    exact ⟨cert.strategy, cert.cost_le, cert.good_on⟩
  · rintro ⟨π, hcost, hgood⟩
    exact ⟨⟨π, hcost, hgood⟩⟩

/-- PROBE certificate.  The observation is useful when the current ambiguity
    block is inadmissible but every nonempty observation fiber inside that
    block is admissible. -/
structure ProbeCertificate
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) (Y : Type*) where
  observe : S → Y
  initial_inadmissible : ¬ Admissible sys b B
  fibers_admissible :
    ∀ y : Y,
      Set.Nonempty (B ∩ {s : S | observe s = y}) →
      Admissible sys b (B ∩ {s : S | observe s = y})

/-- A certified probe resolves the actual post-observation ambiguity cell. -/
theorem probeCertificate_resolves_actual
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) (Y : Type*)
    (cert : ProbeCertificate sys b B Y)
    {s : S} (hs : s ∈ B) :
    Admissible sys b
      (B ∩ {t : S | cert.observe t = cert.observe s}) := by
  apply cert.fibers_admissible (cert.observe s)
  exact ⟨s, hs, rfl⟩

/-- A capability extension embeds every old strategy into the new system,
    never increasing its cost and preserving every old success.  New
    strategies may exist in `Plan'` beyond the image of `lift`. -/
structure CapabilityExtension
    (old : ContractSystem S Plan) (new : ContractSystem S Plan') where
  lift : Plan → Plan'
  cost_nonincrease : ∀ π : Plan, new.cost (lift π) ≤ old.cost π
  good_preserve : ∀ s : S, ∀ π : Plan, old.good s π → new.good s (lift π)

/-- Capability extension cannot destroy an already admissible block. -/
theorem admissible_of_capabilityExtension
    (old : ContractSystem S Plan) (new : ContractSystem S Plan')
    (ext : CapabilityExtension old new)
    (b : Nat) (B : Set S) :
    Admissible old b B → Admissible new b B := by
  rintro ⟨π, hcost, hgood⟩
  refine ⟨ext.lift π, le_trans (ext.cost_nonincrease π) hcost, ?_⟩
  intro s hs
  exact ext.good_preserve s π (hgood s hs)

/-- REPAIR certificate: the current system fails on `B`, while a genuine
    capability extension makes the same ambiguity block admissible without
    changing the contract or budget. -/
structure RepairCertificate
    (old : ContractSystem S Plan) (new : ContractSystem S Plan')
    (b : Nat) (B : Set S) where
  extension : CapabilityExtension old new
  before_inadmissible : ¬ Admissible old b B
  after_admissible : Admissible new b B

/-- Every REPAIR certificate crosses the contractual feasibility frontier. -/
theorem repairCertificate_crosses_frontier
    (old : ContractSystem S Plan) (new : ContractSystem S Plan')
    (b : Nat) (B : Set S)
    (cert : RepairCertificate old new b B) :
    (¬ Admissible old b B) ∧ Admissible new b B := by
  exact ⟨cert.before_inadmissible, cert.after_admissible⟩

/-- PRESERVE certificate: the current representation is beta-safe, but a
    proposed deterministic post-processing/coarsening would make it unsafe. -/
structure PreserveCertificate
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (h : S → Z) (g : Z → Y) where
  before_safe : BetaSafe sys b h
  after_unsafe : ¬ BetaSafe sys b (g ∘ h)

/-- A certified PRESERVE event is exactly a safe-to-unsafe proposed
    transformation and therefore must be blocked if the contract is fixed. -/
theorem preserveCertificate_blocks_coarsening
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat)
    (h : S → Z) (g : Z → Y)
    (cert : PreserveCertificate sys b h g) :
    BetaSafe sys b h ∧ ¬ BetaSafe sys b (g ∘ h) := by
  exact ⟨cert.before_safe, cert.after_unsafe⟩

/-- REFUSE is necessarily relative to an explicitly declared class of allowed
    interventions.  A refusal certificate proves the current block is
    inadmissible and that none of the allowed interventions restores it. -/
structure RefuseCertificate
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S)
    (I : Type*) (restores : I → Prop) where
  current_inadmissible : ¬ Admissible sys b B
  no_allowed_restore : ∀ i : I, ¬ restores i

/-- Soundness of relative refusal: no declared allowed intervention restores
    feasibility. -/
theorem refuseCertificate_no_restore
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S)
    (I : Type*) (restores : I → Prop)
    (cert : RefuseCertificate sys b B I restores) :
    ¬ ∃ i : I, restores i := by
  rintro ⟨i, hi⟩
  exact cert.no_allowed_restore i hi

/-- Beta-form ACT predicate. -/
def Act
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) : Prop :=
  beta sys B ≤ (b : WithTop Nat)

/-- ACT in beta form is exactly ordinary admissibility. -/
theorem act_iff_admissible
    [Fintype Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Set S) :
    Act sys b B ↔ Admissible sys b B := by
  simpa [Act] using beta_le_iff_admissible sys B b

end Insacermo
-- ===== CompilerTernary.lean =====

namespace Insacermo

open TState TPlan

inductive TObs where
  | left | right
  deriving DecidableEq

instance : Fintype TObs where
  elems := {.left, .right}
  complete := by intro x; cases x <;> simp

open TObs

def ternaryObserve : TState → TObs
  | a => left
  | b => left
  | c => right

/-- The ternary obstruction is PROBE-resolvable at budget 1 by separating
    `{a,b}` from `{c}`. -/
theorem ternary_probe_certificate :
    ProbeCertificate ternarySystem 1 (Set.univ : Set TState) TObs := by
  refine {
    observe := ternaryObserve
    initial_inadmissible := triple_not_admissible
    fibers_admissible := ?_
  }
  intro y hy
  cases y with
  | left =>
      refine ⟨ab, by decide, ?_⟩
      intro s hs
      rcases hs with ⟨-, hobs⟩
      cases s with
      | a => trivial
      | b => trivial
      | c => simp [ternaryObserve] at hobs
  | right =>
      refine ⟨ac, by decide, ?_⟩
      intro s hs
      rcases hs with ⟨-, hobs⟩
      cases s with
      | a => simp [ternaryObserve] at hobs
      | b => simp [ternaryObserve] at hobs
      | c => trivial

/-- Extended strategy language used to demonstrate a genuine REPAIR by adding
    one new universal budget-1 capability while preserving every old plan. -/
inductive TPlanPlus where
  | old : TPlan → TPlanPlus
  | universal : TPlanPlus
  deriving DecidableEq

instance : Fintype TPlanPlus where
  elems := {.old .ab, .old .ac, .old .bc, .old .all, .universal}
  complete := by
    intro x
    cases x with
    | old p => cases p <;> simp
    | universal => simp

open TPlanPlus

def ternaryRepairedSystem : ContractSystem TState TPlanPlus where
  good := fun s π =>
    match π with
    | old p => ternarySystem.good s p
    | universal => True
  cost := fun π =>
    match π with
    | old p => ternarySystem.cost p
    | universal => 1

def ternaryCapabilityExtension :
    CapabilityExtension ternarySystem ternaryRepairedSystem where
  lift := old
  cost_nonincrease := by
    intro π
    rfl
  good_preserve := by
    intro s π h
    exact h

theorem ternary_repaired_at_one :
    Admissible ternaryRepairedSystem 1 (Set.univ : Set TState) := by
  refine ⟨universal, by decide, ?_⟩
  intro s hs
  trivial

theorem ternary_repair_certificate :
    RepairCertificate ternarySystem ternaryRepairedSystem 1
      (Set.univ : Set TState) := by
  exact {
    extension := ternaryCapabilityExtension
    before_inadmissible := triple_not_admissible
    after_admissible := ternary_repaired_at_one
  }

/-- Fine two-code representation: `{a,b}` and `{c}`. -/
def ternaryFine : TState → Fin 2
  | a => 0
  | b => 0
  | c => 1

/-- Complete coarsening to one code. -/
def forgetAll : Fin 2 → Fin 1 := fun _ => 0

theorem ternaryFine_betaSafe :
    BetaSafe ternarySystem 1 ternaryFine := by
  intro z hz
  fin_cases z
  · have hsub : {s : TState | ternaryFine s = 0} ⊆ AB := by
      intro s hs
      cases s with
      | a => simp [AB]
      | b => simp [AB]
      | c => simp [ternaryFine] at hs
    exact le_trans (beta_mono_ambiguity ternarySystem hsub) beta_AB_le_one
  · have hc : beta ternarySystem ({c} : Set TState) ≤ (1 : WithTop Nat) := by
      apply (beta_le_iff_admissible ternarySystem ({c} : Set TState) 1).2
      refine ⟨ac, by decide, ?_⟩
      intro s hs
      have hsc : s = c := by simpa using hs
      subst s
      trivial
    have hsub : {s : TState | ternaryFine s = 1} ⊆ ({c} : Set TState) := by
      intro s hs
      cases s with
      | a => simp [ternaryFine] at hs
      | b => simp [ternaryFine] at hs
      | c => simp
    exact le_trans (beta_mono_ambiguity ternarySystem hsub) hc

theorem ternaryForgetAll_unsafe :
    ¬ BetaSafe ternarySystem 1 (forgetAll ∘ ternaryFine) := by
  intro hsafe
  have hz : Set.Nonempty {s : TState | (forgetAll ∘ ternaryFine) s = (0 : Fin 1)} :=
    ⟨a, by simp [forgetAll, ternaryFine]⟩
  have hb := hsafe 0 hz
  have hEq : {s : TState | (forgetAll ∘ ternaryFine) s = (0 : Fin 1)} = Set.univ := by
    ext s
    simp [forgetAll]
  have : beta ternarySystem (Set.univ : Set TState) ≤ (1 : WithTop Nat) := by
    simpa [hEq] using hb
  exact beta_triple_not_le_one this

theorem ternary_preserve_certificate :
    PreserveCertificate ternarySystem 1 ternaryFine forgetAll := by
  exact {
    before_safe := ternaryFine_betaSafe
    after_unsafe := ternaryForgetAll_unsafe
  }

end Insacermo
-- ===== ExecutableCompiler.lean =====

namespace Insacermo

/-- V0.6 distinguishes semantic decisions from search incompleteness.
    `incomplete` is an engine status, not an INSACERMO intervention. -/
inductive ExecLabel where
  | act
  | probe
  | repair
  | preserve
  | refuse
  | incomplete
  deriving DecidableEq, Repr

variable {S Plan : Type*}

/-- A finite executable state. `available` is the strategy set that may be used
    now. Candidate probes, repairs and proposed forgetting steps are explicitly
    enumerated, so REFUSE can be interpreted relative to that declared search
    space. -/
structure ExecInput (S Plan : Type*) [DecidableEq S] [DecidableEq Plan] where
  sys : ContractSystem S Plan
  ambiguity : Finset S
  available : Finset Plan
  budget : Nat
  probes : List (S → Nat) := []
  repairs : List (Finset Plan) := []
  forgets : List (Finset S) := []
  /-- True only when the declared PROBE/REPAIR search space is intended to be
      exhaustive for the current contract. -/
  searchComplete : Bool := false

/-- Restricted feasibility of one explicit strategy in the current finite
    strategy set. -/
def ExecFeasible
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) (available : Finset Plan)
    (b : Nat) (B : Finset S) (π : Plan) : Prop :=
  π ∈ available ∧ sys.cost π ≤ b ∧ ∀ s : S, s ∈ B → sys.good s π

/-- Search a finite list for the first strategy carrying the current contract.
    This is executable whenever `good` is decidable. -/
def findFeasibleAux
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S) :
    List Plan → Option Plan
  | [] => none
  | π :: rest =>
      if _h : ExecFeasible sys available b B π then
        some π
      else
        findFeasibleAux sys available b B rest

/-- ACT search restricted to the explicitly available strategies. -/
def findAct?
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S) : Option Plan :=
  findFeasibleAux sys available b B available.toList

/-- Any strategy returned by the finite ACT search is a genuine feasible
    witness. -/
theorem findFeasibleAux_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    {L : List Plan} {π : Plan}
    (h : findFeasibleAux sys available b B L = some π) :
    ExecFeasible sys available b B π := by
  induction L with
  | nil =>
      simp [findFeasibleAux] at h
  | cons a rest ih =>
      by_cases ha : ExecFeasible sys available b B a
      · simp [findFeasibleAux, ha] at h
        subst π
        exact ha
      · simp [findFeasibleAux, ha] at h
        exact ih h

/-- Soundness of a strategy returned by `findAct?`. -/
theorem findAct_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    {π : Plan} (h : findAct? sys available b B = some π) :
    ExecFeasible sys available b B π := by
  exact findFeasibleAux_sound sys available b B h

/-- Observation cell inside the current ambiguity set. -/
def observationFiber
    [DecidableEq S]
    (B : Finset S) (observe : S → Nat) (y : Nat) : Finset S :=
  B.filter (fun s => observe s = y)

/-- The finite labels actually produced on `B`. -/
def observationLabels
    [DecidableEq S]
    (B : Finset S) (observe : S → Nat) : Finset Nat :=
  B.image observe

/-- Check every observation cell by searching for an ACT witness in that cell. -/
def probeLabelsResolve
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (observe : S → Nat) : List Nat → Bool
  | [] => true
  | y :: rest =>
      match findAct? sys available b (observationFiber B observe y) with
      | some _ => probeLabelsResolve sys available b B observe rest
      | none => false

/-- A probe resolves the current ambiguity when every nonempty fiber generated
    on the current block has a feasible common strategy. -/
def probeResolves
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (observe : S → Nat) : Bool :=
  probeLabelsResolve sys available b B observe
    (observationLabels B observe).toList

/-- First list index satisfying an executable predicate. -/
def firstIndexWhere {α : Type*} (p : α → Bool) : Nat → List α → Option Nat
  | _, [] => none
  | i, x :: xs => if p x then some i else firstIndexWhere p (i + 1) xs

/-- Search candidate probes. -/
def findProbe?
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (probes : List (S → Nat)) : Option Nat :=
  firstIndexWhere (fun q => probeResolves sys available b B q) 0 probes

/-- Search candidate capability additions. A repair may add strategies but does
    not change the worlds, contract or budget. -/
def findRepairAux
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S) :
    Nat → List (Finset Plan) → Option (Nat × Plan)
  | _, [] => none
  | i, added :: rest =>
      match findAct? sys (available ∪ added) b B with
      | some π => some (i, π)
      | none => findRepairAux sys available b B (i + 1) rest

/-- Search the enumerated repair candidates. -/
def findRepair?
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (repairs : List (Finset Plan)) : Option (Nat × Plan) :=
  findRepairAux sys available b B 0 repairs

/-- A proposed coarsening is a PRESERVE threat when the current block is
    feasible, the proposal truly enlarges that block, and the proposed block
    has no ACT witness under unchanged capability and budget. -/
def preserveThreat
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B proposed : Finset S) : Bool :=
  decide (B ⊆ proposed) &&
    (match findAct? sys available b proposed with
     | some _ => false
     | none => true)

/-- Search proposed forgetting/coarsening moves for the first unsafe one. -/
def findPreserve?
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (forgets : List (Finset S)) : Option Nat :=
  firstIndexWhere (fun proposed => preserveThreat sys available b B proposed) 0 forgets

/-- Compact executable output. The candidate index refers to the corresponding
    input list (`forgets`, `probes` or `repairs`). A strategy is returned for
    ACT and REPAIR. -/
structure ExecResult (Plan : Type*) where
  label : ExecLabel
  candidateIndex : Option Nat := none
  strategy : Option Plan := none
  deriving Repr

/-- Executable INSACERMO compiler.

Priority:
1. if current ACT exists, block a declared unsafe forgetting step (PRESERVE),
   otherwise ACT;
2. if current ACT fails, try PROBE;
3. then REPAIR;
4. REFUSE only if the declared search is exhaustive;
5. otherwise report INCOMPLETE.
-/
def compile
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (input : ExecInput S Plan) [DecidableRel input.sys.good] : ExecResult Plan :=
  match findAct? input.sys input.available input.budget input.ambiguity with
  | some π =>
      match findPreserve? input.sys input.available input.budget
          input.ambiguity input.forgets with
      | some i => ⟨.preserve, some i, some π⟩
      | none => ⟨.act, none, some π⟩
  | none =>
      match findProbe? input.sys input.available input.budget
          input.ambiguity input.probes with
      | some i => ⟨.probe, some i, none⟩
      | none =>
          match findRepair? input.sys input.available input.budget
              input.ambiguity input.repairs with
          | some (i, π) => ⟨.repair, some i, some π⟩
          | none =>
              if input.searchComplete then
                ⟨.refuse, none, none⟩
              else
                ⟨.incomplete, none, none⟩

end Insacermo
-- ===== ExecutableTernary.lean =====

namespace Insacermo

open TState

/-- Separate executable strategy universe.  The first three strategies are the
    old pair capabilities; `universalOne` is the genuinely new budget-1 repair. -/
inductive EPlan where
  | ab | ac | bc | universalOne
  deriving DecidableEq, Repr

instance : Fintype EPlan where
  elems := {.ab, .ac, .bc, .universalOne}
  complete := by intro x; cases x <;> simp

open EPlan

def eGood : TState → EPlan → Prop
  | .a, .ab => True
  | .b, .ab => True
  | .a, .ac => True
  | .c, .ac => True
  | .b, .bc => True
  | .c, .bc => True
  | _, .universalOne => True
  | _, _ => False

def eCost : EPlan → Nat
  | .ab | .ac | .bc | .universalOne => 1

def executableTernarySystem : ContractSystem TState EPlan where
  good := eGood
  cost := eCost

instance executableTernaryGoodDecidable :
    DecidableRel executableTernarySystem.good := by
  intro s π
  cases s <;> cases π <;> simp [executableTernarySystem, eGood]

/-- Finset form of the full ternary ambiguity. -/
def ternaryWorlds : Finset TState := {.a, .b, .c}

/-- Initially only the three pair capabilities are available. -/
def ternaryAvailable : Finset EPlan := {.ab, .ac, .bc}

/-- Probe separating `{a,b}` from `{c}`. -/
def execTernaryProbe : TState → Nat
  | .a => 0
  | .b => 0
  | .c => 1

/-- Genuine capability repair: add the new universal budget-1 strategy. -/
def execTernaryRepair : Finset EPlan := {.universalOne}

/-- Current pair ambiguity used for ACT/PRESERVE tests. -/
def ternaryAB : Finset TState := {.a, .b}

/-- Triple ambiguity: ACT fails; candidate 0 is a successful PROBE. -/
def ternaryExecProbeInput : ExecInput TState EPlan where
  sys := executableTernarySystem
  ambiguity := ternaryWorlds
  available := ternaryAvailable
  budget := 1
  probes := [execTernaryProbe]
  repairs := [execTernaryRepair]
  forgets := []
  searchComplete := true

/-- Same state with no probe candidate: candidate 0 is a successful REPAIR. -/
def ternaryExecRepairInput : ExecInput TState EPlan where
  sys := executableTernarySystem
  ambiguity := ternaryWorlds
  available := ternaryAvailable
  budget := 1
  probes := []
  repairs := [execTernaryRepair]
  forgets := []
  searchComplete := true

/-- Pair ambiguity is ACT-safe, but expanding it to the triple is a PRESERVE
    threat at budget 1 with current capabilities. -/
def ternaryExecPreserveInput : ExecInput TState EPlan where
  sys := executableTernarySystem
  ambiguity := ternaryAB
  available := ternaryAvailable
  budget := 1
  probes := []
  repairs := []
  forgets := [ternaryWorlds]
  searchComplete := true

/-- No probe/repair candidates and declared exhaustive search: relative REFUSE. -/
def ternaryExecRefuseInput : ExecInput TState EPlan where
  sys := executableTernarySystem
  ambiguity := ternaryWorlds
  available := ternaryAvailable
  budget := 1
  probes := []
  repairs := []
  forgets := []
  searchComplete := true

/-- Same missing candidates, but non-exhaustive search: INCOMPLETE, not REFUSE. -/
def ternaryExecIncompleteInput : ExecInput TState EPlan where
  sys := executableTernarySystem
  ambiguity := ternaryWorlds
  available := ternaryAvailable
  budget := 1
  probes := []
  repairs := []
  forgets := []
  searchComplete := false

end Insacermo
-- ===== OperationalSemantics.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- Operational admissibility relative to the strategies that are *currently
    available*.  This is the semantic notion matched by the V0.6 executable
    compiler.  It deliberately differs from `Admissible`, which quantifies over
    the whole strategy type `Plan`. -/
def FiniteAdmissible
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) (available : Finset Plan)
    (b : Nat) (B : Finset S) : Prop :=
  ∃ π : Plan, ExecFeasible sys available b B π

/-- Restricted feasibility always implies the older unrestricted semantics. -/
theorem finiteAdmissible_implies_admissible
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) (available : Finset Plan)
    (b : Nat) (B : Finset S) :
    FiniteAdmissible sys available b B →
      Admissible sys b (↑B : Set S) := by
  rintro ⟨π, hmem, hcost, hgood⟩
  refine ⟨π, hcost, ?_⟩
  intro s hs
  exact hgood s hs

/-- When every strategy is available, operational and unrestricted
    admissibility coincide.  This is the bridge from V0.7 back to the V0.1–V0.5
    semantics. -/
theorem finiteAdmissible_univ_iff_admissible
    [Fintype S] [Fintype Plan] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) (b : Nat) (B : Finset S) :
    FiniteAdmissible sys Finset.univ b B ↔
      Admissible sys b (↑B : Set S) := by
  constructor
  · exact finiteAdmissible_implies_admissible sys Finset.univ b B
  · rintro ⟨π, hcost, hgood⟩
    refine ⟨π, ?_⟩
    refine ⟨Finset.mem_univ π, hcost, ?_⟩
    intro s hs
    exact hgood s hs

/-- Semantic meaning of each executable label.  REFUSE is explicitly relative
    to the declared candidate search: the Boolean `searchComplete` is a trusted
    declaration that those candidates exhaust the allowed intervention class.
    INCOMPLETE records the same failed finite search without that declaration. -/
def OperationalSound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (input : ExecInput S Plan) [DecidableRel input.sys.good]
    (out : ExecResult Plan) : Prop :=
  match out.label with
  | .act =>
      FiniteAdmissible input.sys input.available input.budget input.ambiguity
  | .preserve =>
      FiniteAdmissible input.sys input.available input.budget input.ambiguity ∧
      ∃ proposed ∈ input.forgets,
        input.ambiguity ⊆ proposed ∧
        ¬ FiniteAdmissible input.sys input.available input.budget proposed
  | .probe =>
      ¬ FiniteAdmissible input.sys input.available input.budget input.ambiguity ∧
      ∃ observe ∈ input.probes,
        ∀ y ∈ observationLabels input.ambiguity observe,
          FiniteAdmissible input.sys input.available input.budget
            (observationFiber input.ambiguity observe y)
  | .repair =>
      ¬ FiniteAdmissible input.sys input.available input.budget input.ambiguity ∧
      ∃ added ∈ input.repairs,
        FiniteAdmissible input.sys (input.available ∪ added)
          input.budget input.ambiguity
  | .refuse =>
      ¬ FiniteAdmissible input.sys input.available input.budget input.ambiguity ∧
      input.searchComplete = true ∧
      findProbe? input.sys input.available input.budget input.ambiguity
        input.probes = none ∧
      findRepair? input.sys input.available input.budget input.ambiguity
        input.repairs = none
  | .incomplete =>
      ¬ FiniteAdmissible input.sys input.available input.budget input.ambiguity ∧
      input.searchComplete = false ∧
      findProbe? input.sys input.available input.budget input.ambiguity
        input.probes = none ∧
      findRepair? input.sys input.available input.budget input.ambiguity
        input.repairs = none

end Insacermo
-- ===== ExecutableSoundness.lean =====

namespace Insacermo

variable {S Plan : Type*}

/-- Failure of the recursive ACT search means that no strategy appearing in the
    searched list is feasible. -/
theorem findFeasibleAux_none_iff
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (L : List Plan) :
    findFeasibleAux sys available b B L = none ↔
      ∀ π ∈ L, ¬ ExecFeasible sys available b B π := by
  induction L with
  | nil =>
      simp [findFeasibleAux]
  | cons a rest ih =>
      by_cases ha : ExecFeasible sys available b B a
      · simp [findFeasibleAux, ha]
      · simp [findFeasibleAux, ha, ih]

/-- The finite ACT search is complete for the explicitly available strategy
    set. -/
theorem findAct_none_iff_not_finiteAdmissible
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S) :
    findAct? sys available b B = none ↔
      ¬ FiniteAdmissible sys available b B := by
  unfold findAct?
  rw [findFeasibleAux_none_iff]
  constructor
  · intro hnone hAdm
    rcases hAdm with ⟨π, hπ⟩
    exact hnone π (by simpa using hπ.1) hπ
  · intro hnot π hmem hfeas
    exact hnot ⟨π, hfeas⟩

/-- A successful ACT search yields operational admissibility. -/
theorem findAct_some_finiteAdmissible
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    {π : Plan} (h : findAct? sys available b B = some π) :
    FiniteAdmissible sys available b B := by
  exact ⟨π, findAct_sound sys available b B h⟩

/-- Boolean probe checking is sound: every listed observation fiber has a
    genuine finite ACT witness. -/
theorem probeLabelsResolve_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (observe : S → Nat) (L : List Nat)
    (h : probeLabelsResolve sys available b B observe L = true) :
    ∀ y ∈ L,
      FiniteAdmissible sys available b (observationFiber B observe y) := by
  induction L with
  | nil =>
      simp
  | cons y rest ih =>
      cases hact : findAct? sys available b (observationFiber B observe y) with
      | none =>
          simp [probeLabelsResolve, hact] at h
      | some π =>
          have hy : FiniteAdmissible sys available b
              (observationFiber B observe y) :=
            findAct_some_finiteAdmissible sys available b
              (observationFiber B observe y) hact
          have hrest : probeLabelsResolve sys available b B observe rest = true := by
            simpa [probeLabelsResolve, hact] using h
          have iht := ih hrest
          intro y' hy'
          simp only [List.mem_cons] at hy'
          rcases hy' with rfl | hyrest
          · exact hy
          · exact iht y' hyrest

/-- A successful executable probe resolves every observation label actually
    produced on the current ambiguity block. -/
theorem probeResolves_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (observe : S → Nat)
    (h : probeResolves sys available b B observe = true) :
    ∀ y ∈ observationLabels B observe,
      FiniteAdmissible sys available b (observationFiber B observe y) := by
  unfold probeResolves at h
  intro y hy
  apply probeLabelsResolve_sound sys available b B observe
      (observationLabels B observe).toList h y
  simpa using hy

/-- Any successful indexed-list search identifies a real listed candidate whose
    executable predicate is true. -/
theorem firstIndexWhere_sound_mem
    {α : Type*} (p : α → Bool) (i : Nat) (L : List α) {j : Nat}
    (h : firstIndexWhere p i L = some j) :
    ∃ x ∈ L, p x = true := by
  induction L generalizing i with
  | nil =>
      simp [firstIndexWhere] at h
  | cons a rest ih =>
      cases hpa : p a with
      | false =>
          simp [firstIndexWhere, hpa] at h
          rcases ih (i := i + 1) h with ⟨x, hx, hpx⟩
          exact ⟨x, by simp [hx], hpx⟩
      | true =>
          exact ⟨a, by simp, hpa⟩

/-- A returned PROBE index corresponds to an actually resolving candidate. -/
theorem findProbe_sound_exists
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (probes : List (S → Nat)) {i : Nat}
    (h : findProbe? sys available b B probes = some i) :
    ∃ observe ∈ probes,
      ∀ y ∈ observationLabels B observe,
        FiniteAdmissible sys available b (observationFiber B observe y) := by
  unfold findProbe? at h
  rcases firstIndexWhere_sound_mem
      (fun q => probeResolves sys available b B q) 0 probes h with
    ⟨observe, hmem, htrue⟩
  refine ⟨observe, hmem, ?_⟩
  exact probeResolves_sound sys available b B observe htrue

/-- A returned REPAIR candidate really makes the unchanged ambiguity block
    feasible after adding the corresponding capability set. -/
theorem findRepairAux_sound_exists
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (i0 : Nat) (repairs : List (Finset Plan)) {out : Nat × Plan}
    (h : findRepairAux sys available b B i0 repairs = some out) :
    ∃ added ∈ repairs,
      FiniteAdmissible sys (available ∪ added) b B := by
  induction repairs generalizing i0 with
  | nil =>
      simp [findRepairAux] at h
  | cons added rest ih =>
      cases hact : findAct? sys (available ∪ added) b B with
      | some π =>
          refine ⟨added, by simp, ?_⟩
          exact findAct_some_finiteAdmissible sys (available ∪ added) b B hact
      | none =>
          simp [findRepairAux, hact] at h
          rcases ih (i0 := i0 + 1) h with ⟨added', hmem, hAdm⟩
          exact ⟨added', by simp [hmem], hAdm⟩

/-- Soundness of the top-level REPAIR search. -/
theorem findRepair_sound_exists
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (repairs : List (Finset Plan)) {out : Nat × Plan}
    (h : findRepair? sys available b B repairs = some out) :
    ∃ added ∈ repairs,
      FiniteAdmissible sys (available ∪ added) b B := by
  exact findRepairAux_sound_exists sys available b B 0 repairs h

/-- A positive PRESERVE predicate is a genuine safe-to-unsafe ambiguity
    enlargement relative to the current available capabilities. -/
theorem preserveThreat_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B proposed : Finset S)
    (h : preserveThreat sys available b B proposed = true) :
    B ⊆ proposed ∧
      ¬ FiniteAdmissible sys available b proposed := by
  by_cases hsub : B ⊆ proposed
  · cases hact : findAct? sys available b proposed with
    | some π =>
        simp [preserveThreat, hsub, hact] at h
    | none =>
        refine ⟨hsub, ?_⟩
        exact (findAct_none_iff_not_finiteAdmissible
          sys available b proposed).1 hact
  · simp [preserveThreat, hsub] at h

/-- A returned PRESERVE index corresponds to a listed unsafe coarsening. -/
theorem findPreserve_sound_exists
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (sys : ContractSystem S Plan) [DecidableRel sys.good]
    (available : Finset Plan) (b : Nat) (B : Finset S)
    (forgets : List (Finset S)) {i : Nat}
    (h : findPreserve? sys available b B forgets = some i) :
    ∃ proposed ∈ forgets,
      B ⊆ proposed ∧
      ¬ FiniteAdmissible sys available b proposed := by
  unfold findPreserve? at h
  rcases firstIndexWhere_sound_mem
      (fun proposed => preserveThreat sys available b B proposed)
      0 forgets h with ⟨proposed, hmem, htrue⟩
  rcases preserveThreat_sound sys available b B proposed htrue with
    ⟨hsub, hbad⟩
  exact ⟨proposed, hmem, hsub, hbad⟩

/-- V0.7 main theorem: every label produced by the executable compiler has its
    declared operational semantics.  REFUSE remains relative to the trusted
    `searchComplete` declaration; INCOMPLETE is used otherwise. -/
theorem compile_operational_sound
    [Fintype S] [DecidableEq S] [DecidableEq Plan]
    (input : ExecInput S Plan) [DecidableRel input.sys.good] :
    OperationalSound input (compile input) := by
  unfold compile
  cases hact : findAct? input.sys input.available input.budget input.ambiguity with
  | some π =>
      have hcurrent : FiniteAdmissible input.sys input.available
          input.budget input.ambiguity :=
        findAct_some_finiteAdmissible input.sys input.available
          input.budget input.ambiguity hact
      cases hpres : findPreserve? input.sys input.available input.budget
          input.ambiguity input.forgets with
      | some i =>
          rcases findPreserve_sound_exists input.sys input.available
              input.budget input.ambiguity input.forgets hpres with
            ⟨proposed, hmem, hsub, hbad⟩
          simp [OperationalSound, hact, hpres]
          exact ⟨hcurrent, proposed, hmem, hsub, hbad⟩
      | none =>
          simp [OperationalSound, hact, hpres]
          exact hcurrent
  | none =>
      have hcurrent : ¬ FiniteAdmissible input.sys input.available
          input.budget input.ambiguity :=
        (findAct_none_iff_not_finiteAdmissible input.sys input.available
          input.budget input.ambiguity).1 hact
      cases hprobe : findProbe? input.sys input.available input.budget
          input.ambiguity input.probes with
      | some i =>
          rcases findProbe_sound_exists input.sys input.available input.budget
              input.ambiguity input.probes hprobe with
            ⟨observe, hmem, hfibers⟩
          simp [OperationalSound, hact, hprobe]
          exact ⟨hcurrent, observe, hmem, hfibers⟩
      | none =>
          cases hrepair : findRepair? input.sys input.available input.budget
              input.ambiguity input.repairs with
          | some out =>
              rcases findRepair_sound_exists input.sys input.available input.budget
                  input.ambiguity input.repairs hrepair with
                ⟨added, hmem, hafter⟩
              simp [OperationalSound, hact, hprobe, hrepair]
              exact ⟨hcurrent, added, hmem, hafter⟩
          | none =>
              cases hcomplete : input.searchComplete with
              | false =>
                  simp [OperationalSound, hact, hprobe, hrepair, hcomplete]
                  exact ⟨hcurrent, hcomplete, hprobe, hrepair⟩
              | true =>
                  simp [OperationalSound, hact, hprobe, hrepair, hcomplete]
                  exact ⟨hcurrent, hcomplete, hprobe, hrepair⟩

end Insacermo
